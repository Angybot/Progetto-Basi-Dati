-- DML 
INSERT INTO UTENTE (IDUtente, Nome, Cognome, Email, Via, CAP, Citta, NumeroCivico) VALUES
(1, 'Mario', 'Rossi', 'mario.rossi@email.it', 'Via Roma', '00100', 'Roma', '10'),
(2, 'Mario', 'Bianchi', 'mario.b@email.com', 'Corso Garibaldi', '20121', 'Milano', '1'),
(3, 'Laura', 'Bianchi', 'laura.b@email.com', 'Corso Milano', '20121', 'Milano', '5/A'),
(4, 'Pasquale', 'Neri', 'neri.p@email.com', 'Corso Napoli', '20235', 'Napoli', '31'),
(5, 'Giancarlo', 'Bianchi', 'gian.b@email.com', 'Via Aldo Moro', '20121', 'Milano', '2');


INSERT INTO TELEFONO (Numero, Utente) VALUES
('3331234567', 1),
('0655566632', 1),
('3347536543', 2),
('3669834543', 3),
('3663945778', 4),
('3323425225', 4);

INSERT INTO AUTISTA (IDPersonale, Nome, Cognome, NumeroPatente) VALUES
(1, 'Giuseppe', 'Verdi', 'U1B998877F'),
(2, 'Giacomo', 'Verdi', 'U4B888877A'),
(3, 'Giuseppe', 'Rossi', 'U6B778877G'),
(4, 'Alberto', 'Marroni', 'U8B668433F'),
(5, 'Incazzato', 'Nero', 'U3B558855I'),
(6, 'Antonio', 'Neri', 'U8C112233G');

INSERT INTO CONTROLLORE (IDPersonale, Nome, Cognome) VALUES
(1, 'Marco', 'Gialli'),
(2, 'Rosa', 'Rosa'),
(3, 'Elena', 'Viola');

INSERT INTO BUS (CodiceBus, Azienda, Capacità) VALUES
(1, 'Lazio Mobilità', 50),
(2, 'Roma Viaggi', 60),
(3, 'Napoli Trasporti', 30),
(4, 'Salerno Bus', 80),
(5, 'Milano Trasporti', 35),
(6, 'Milano Trasporti', 70),
(7, 'Salerno Bus', 40);

INSERT INTO GUIDARE (Bus, Autista, Data) VALUES
(1, 1, '2025-05-26'),
(1, 4, '2025-10-11'),
(2, 3, '2026-01-20'),
(2, 5, '2025-10-11'),
(3, 1, '2026-01-20'),
(4, 5, '2025-11-20'),
(4, 3, '2025-01-06'),
(5, 2, '2025-09-20'),
(5, 2, '2025-10-11'),
(3, 5, '2025-10-11'),
(3, 3, '2025-09-20'),
(5, 5, '2026-01-20'),
(1, 5, '2025-09-13'),
(6, 5, '2025-07-16'),
(7, 5, '2026-02-06');

INSERT INTO TRATTA (IDTratta, Data, OrarioPartenza, OrarioArrivo, Partenza, Arrivo, NumeroPostiDisponibili, Bus) VALUES
(1, '2025-05-20', '08:00:00', '11:00:00', 'Roma', 'Firenze', 50, 1),
(2, '2025-05-20', '14:30:00', '16:00:00', 'Milano', 'Torino', 35, 5),
(3, '2026-01-11', '14:30:00', '16:00:00', 'Milano', 'Firenze', 35, 5),
(4, '2026-01-11', '18:30:00', '22:00:00', 'Firenze', 'Salerno', 80, 4),
(5, '2026-01-20', '15:00:00', '16:00:00', 'Roma', 'Napoli', 50, 1),
(6, '2026-01-20', '07:30:00', '16:00:00', 'Milano', 'Salerno', 80, 4),
(7, '2026-02-05', '14:30:00', '18:00:00', 'Napoli', 'Firenze', 30, 3);

-- Prenotazione già controllata
INSERT INTO PRENOTAZIONE (Utente, Tratta, Controllore, DataControllo, EsitoControllo) VALUES
(1, 1, 1, '2025-05-20 08:15:00', 'Valido'),
(2, 2, 1, '2025-05-20 14:45:30', 'Valido'),
(3, 2, 1, '2025-05-20 14:47:50', 'Non Valido'),
(3, 3, 1, '2026-01-11 14:40:25', 'Valido'),
(4, 4, 1, '2026-01-11 19:15:00', 'Non Valido'),
(3, 7, 1, '2026-02-05 15:00:40', 'Valido');

-- Prenotazione effettuata ma non ancora controllata (i campi con * rimangono NULL)
INSERT INTO PRENOTAZIONE (Utente, Tratta) VALUES
(2, 1),
(3, 1),
(1, 2),
(4, 2),
(4, 3),
(2, 6),
(3, 4),
(1, 6),
(2, 7);
