USE BaseDatiBus;
-- Mostra chi deve viaggiare, su quale bus e se il biglietto è già stato controllato
SELECT U.Cognome, U.Nome, T.Partenza, T.Arrivo, P.EsitoControllo, B.Azienda
FROM PRENOTAZIONE P
JOIN UTENTE U ON P.Utente = U.IDUtente
JOIN TRATTA T ON P.Tratta = T.IDTratta
JOIN BUS B ON T.Bus = B.CodiceBus;

-- Controllo sugli UTENTI (Nomi, Cognomi o Email mancanti)
SELECT *
FROM UTENTE 
WHERE Nome IS NULL OR Cognome IS NULL OR Email IS NULL;

-- Controllo sugli AUTISTI
SELECT *
FROM AUTISTA 
WHERE Nome IS NULL OR Cognome IS NULL;

-- Controllo sui BUS (Capacità o Targa mancante)
SELECT *
FROM BUS 
WHERE CodiceBus IS NULL OR Capacità IS NULL;

-- Conta i NULL
SELECT 
    (SELECT COUNT(*) FROM UTENTE WHERE Nome = '' OR Nome IS NULL) AS Utenti_da_cancellare,
    (SELECT COUNT(*) FROM AUTISTA WHERE Nome = '' OR Nome IS NULL) AS Autisti_da_cancellare,
    (SELECT COUNT(*) FROM BUS WHERE CodiceBus = '' OR CodiceBus IS NULL) AS Bus_da_cancellare;
    
-- Pulizia Utenti
DELETE FROM UTENTE 
WHERE Nome IS NULL OR Nome = '' OR Cognome IS NULL OR Cognome = '';

-- Pulizia Autisti
DELETE FROM AUTISTA 
WHERE Nome IS NULL OR Nome = '' OR Cognome IS NULL OR Cognome = '';

-- Pulizia Bus
DELETE FROM BUS 
WHERE CodiceBus IS NULL OR Azienda IS NULL;