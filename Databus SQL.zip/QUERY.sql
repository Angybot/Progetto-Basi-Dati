USE BaseDatiBus;
-- Query 1: Visualizza tutti gli utenti di cognome Bianchi, che abitano o a Corso Milano o a Corso Garibaldi ordinati per nome
SELECT *
FROM UTENTE AS U
WHERE U.Cognome='Bianchi' AND (U.Via ='Corso Milano' OR U.Via = 'Corso Garibaldi')
ORDER BY U.Nome;

-- Query 2: Selezione i dati degli autisti che hanno guidato bus l'11 Ottobre 2025
SELECT B.Azienda, B.Capacità, A.Nome, A.Cognome, A.NumeroPatente
FROM GUIDARE AS G
JOIN BUS AS B ON B.CodiceBus = G.Bus
JOIN AUTISTA AS A ON A.IDPersonale = G.Autista
WHERE G.Data='2025-10-11';

-- Query 3: Somma le capacità di tutti i pullman presenti nel database
SELECT SUM(Capacità) AS Capacità_totale
FROM BUS;

-- Query 4: Conta quanti bus partono da ogni città di partenza
SELECT Partenza, COUNT(*) AS Numero_Corse
FROM TRATTA
GROUP BY Partenza;

-- Query 5: Utenti che hanno effettuato più di 2 prenotazioni
SELECT U.IDUtente, U.Cognome, U.Nome, U.Email , COUNT(*) AS Numero_Prenotazioni
FROM PRENOTAZIONE AS P
JOIN UTENTE U ON U.IDUtente = P.Utente
GROUP BY U.Email
HAVING COUNT(*) >= 3;

-- Query 6: Trovare l'azienda che possiede la capacità di trasporto più alta
SELECT Azienda, SUM(Capacità) AS Capacità_Totale
FROM BUS
GROUP BY Azienda
HAVING SUM(Capacità) = (
    -- Subquery che trova il valore massimo tra i totali delle aziende
    SELECT MAX(Totale)
    FROM (
        SELECT SUM(Capacità) AS Totale
        FROM BUS
        GROUP BY Azienda
    ) AS TabellaSottoTotali
);

-- Query 7: Seleziona tutti i punti geografici citati nel database e li conta
SELECT CittàCitata, COUNT(*) AS VolteInCuiVieneCitata
FROM (
    SELECT Citta AS CittàCitata FROM UTENTE
    UNION ALL
    SELECT Partenza FROM TRATTA
    UNION ALL
    SELECT Arrivo FROM TRATTA
) AS TuttiIPunti
GROUP BY CittàCitata
ORDER BY VolteInCuiVieneCitata DESC;

-- Query 8: Cerca tutti gli autisti che hanno guidato tutti i bus
SELECT A.IDPersonale, A.Nome, A.Cognome
FROM AUTISTA AS A
WHERE NOT EXISTS (
    -- Prende tutti i bus esistenti
    SELECT B.CodiceBus 
    FROM BUS AS B
    WHERE NOT EXISTS (
        -- Controlla se l'autista ha guidato questo bus
        SELECT G.Bus 
        FROM GUIDARE AS G 
        WHERE G.Autista = A.IDPersonale 
          AND G.Bus = B.CodiceBus
    )
);
SELECT A.IDPersonale, A.Nome, A.Cognome
FROM AUTISTA AS A
JOIN GUIDARE AS G ON A.IDPersonale = G.Autista
GROUP BY A.IDPersonale, A.Nome, A.Cognome
HAVING COUNT(DISTINCT G.Bus) = (SELECT COUNT(*) FROM BUS);